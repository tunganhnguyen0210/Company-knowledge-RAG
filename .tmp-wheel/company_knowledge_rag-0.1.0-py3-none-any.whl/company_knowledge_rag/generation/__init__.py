"""Grounded answer generation."""
