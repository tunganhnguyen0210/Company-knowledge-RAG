"""Golden-set regression evaluation."""
