"""Document metadata storage."""
