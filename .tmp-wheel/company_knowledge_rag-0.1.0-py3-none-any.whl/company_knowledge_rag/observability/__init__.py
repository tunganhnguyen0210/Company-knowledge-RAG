"""Safe tracing helpers."""
