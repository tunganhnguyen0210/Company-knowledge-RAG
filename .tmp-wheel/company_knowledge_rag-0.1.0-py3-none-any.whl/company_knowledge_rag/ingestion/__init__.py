"""Document ingestion pipeline."""
