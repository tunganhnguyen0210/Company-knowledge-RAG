"""ACL-aware retrieval implementations."""
