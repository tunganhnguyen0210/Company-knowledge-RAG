"""FastAPI application."""
