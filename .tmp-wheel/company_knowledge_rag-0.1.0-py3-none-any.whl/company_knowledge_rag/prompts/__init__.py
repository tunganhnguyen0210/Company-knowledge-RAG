"""Versioned application prompts."""
