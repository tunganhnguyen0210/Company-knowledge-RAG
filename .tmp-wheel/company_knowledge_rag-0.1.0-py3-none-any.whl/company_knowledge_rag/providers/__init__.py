"""Generation and embedding providers."""
